                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3493999
Split flap display with housing by Martin1111 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a remix of excelent design of Hakernia split flap with housing and button added. https://www.thingiverse.com/thing:2369832.

Changes:
1. enlarged flap size (height of approx credit card size for two flaps, a bit wider than credit card).
2. enlarged flaps mean that flap holding wheels had to be enlarged too.
3. 20 holes for flaps
4. One of the wheel parts has place for 10 mm bearing, to hold the wheel in position by M4 screw. I used 10x4x5 flanged bearing I had, but any will do. You may have to change this part to fit your bearing.

For the motor (28BYJ-48), original holder from hakiernia can be used, but in my experience I had to cut away appox. 1 mm from the rim. Otherwise the motor holder was blocking the wheels.

Flaps were designed with numbers 1-20. I printed them on single nozzle printer the following way: 2 layers (0.15 mm each) white, filament change to black for two middle layers, then again 2 layers white.

Housing and back cover: I publish 2 versions - one I actually printed and one with no holes, brackets, cable management features etc.
Housing is ment to hold arduino nano (I remixed one of the brackets on thingiverse), ULN2003 driver (4 screw holes at the bottom of the housing), switch and socket for 12V 2.5/5.5 power supply.
The wheel with flaps is hold in place with M4 screws. M4 nuts are placed inside the box as shown on the pictures.
NOTE: You may want to enlarge the front window by 2-3 mm from the bottom. Sometimes the falling flap bounces back and gets stuck on the outside of the box.
 
Button is remixed and can be found here: https://www.thingiverse.com/thing:3493891

A little bit of code on arduino is ment to randomly display a number (random number of steps for max. 2 full turns).

https://youtu.be/bTTlmoX4MD8


# Print Settings

Resolution: 0.2
Filament_brand: any
Filament_material: PLA