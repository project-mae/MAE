                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2369832
Dead simple split flap display  by hakernia is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Split flap displays were widely used in railway stations, airports etc. I loved watching the boards of the rolling characters. They have mostly been replaced with electronic devices nowadays, The module here is based on a popular cheap stepper motor, 28BYJ-48, driven by arduino. The design represents a single position of a character. It can store 32 characters in it (this is the number of flaps). The motor is hidden inside the body cylinder, so the duplicated devices can be easily placed in a row to make the entire words. No pulleys, no timing belts.

Note 1. The design does not contain any handle. Use two M4 screws to mount it to your preferred base or drill whatever holes you need in the motor holder piece. I used a thick wire to make the temporary stand.

Note 2. The thick wire is also used to set the flipping point of the top flap in this prototype. It was the easiest way to tune the correct position; however, it's just a stopgap solution. For the final design it could be printed extension of the handle or just the front panel.

Note 3. There is no position sensor. The driver keeps counting the steps to identify the currently displayed character. It is not reliable method though. The motor does not make the perfect angle per step, probably due to the gearing. It can be dealt with by adjusting the driver code, but in the long run this particular split-flap is better suited to work as a dice than a display :-) 

Enjoy the flipping!

# Print Settings

Printer: Tevo Black Widow
Rafts: No
Supports: No
Resolution: Normal
Infill: 100%

Notes: 
Keep the flaps thin, max 1mm. I used 3 layers for the flat surface, and fourth layer just for the hinges. This specific item contains a few thicker flaps, for testing purposes. They work less reliable as you can see on the video. The empty characters flip considerably faster than others.

# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/68/97/da/78/2c/20170529_091326a.jpg)
The main body consists of two parts. They fit together tight enough not to require any screws. Slide the blades into the grooves. Do not push the pieces to the very end initially. Leave a few mm gap in order to insert the flaps.

![Alt text](https://cdn.thingiverse.com/assets/1b/03/12/5a/8d/20170602_133702a.jpg)
Inserting the flaps is easier in this position. When all done, push the two body pieces together.

![Alt text](https://cdn.thingiverse.com/assets/fb/8d/8c/17/54/20170529_091213a.jpg)
The body is attached directly to the motor shaft by push. The motor is mounted to its holder part using two M4 screws. The image above shows just the idea. The motor should be insert into the body only when the body is already finished with flaps on it.

![Alt text](https://cdn.thingiverse.com/assets/72/ab/4f/86/7c/letters.jpg)
The best way to cut the letters is using the spouse. Silhouettes or printed rectangles, anything should work!

![Alt text](https://cdn.thingiverse.com/assets/55/1b/5d/c3/b2/stand.jpg)
I wish my spouse were making stands as well. Unfortunately, this task was on me.

# How I Designed This

Designed in Blender 2.78a

![Alt text](https://cdn.thingiverse.com/assets/32/f4/ff/6e/c5/design_1.jpg)

![Alt text](https://cdn.thingiverse.com/assets/2f/51/21/fb/f4/design_2.jpg)

# Custom Section

<iframe src="//www.youtube.com/embed/tbTmgBamKNE" frameborder="0" allowfullscreen></iframe>
Dead simple split-flap display at work!

## The Driver

Due to the popular demand I hereby provide an example driver to run this device:
https://github.com/hakernia/DeadSimpleSplitFlapDisplay
Multi unit version to be added later.