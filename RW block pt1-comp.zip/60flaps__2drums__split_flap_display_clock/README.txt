                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2598383
60flaps * 2drums  split flap display clock by itoshin is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

How it works:

1. According to the time provided by RTC, Arduino moves the 28BYJ-48 stepping motor.
2. The right drum moves one step per minute, and the left drum moves one step per hour. Attach 60 plates to each drum.
3. With a photo reflector in the drum, Arduino knows the absolute angle.

For the four digit split flap display clock I made previously, improved the following things:

1. Reduced the number of motors from 4 to 2.
2. Remove of gear by coaxial arrangement of drum and motor.
3. Wiring hidden in the frame.
4. Reduces the influence of ambient light by changing the position of the infrared sensor.

It takes a long time to paste the number seal. It took me a day. If you have a printer with a dual nozzle and you can make 3D data of a plate with numbers, you can easily print it.

I uploaded Arduino sourse code and schematic.

See also,
https://youtu.be/t2TUIGJOSqw
http://www.instructables.com/id/BYJ48-Stepper-Motor/
http://www.instructables.com/id/Real-time-clock-using-DS3231-EASY/